﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace IMDB.Models
{
    public class Movies
    {
        [Display(Name = "Name")]
        public String Name { get; set; }

        [Required(ErrorMessage = "Year_Of_Release is required.")]
        public string Year_Of_Release { get; set; }

        [Required(ErrorMessage = "Plot is required.")]
        public string Plot { get; set; }

        [Required(ErrorMessage = "Poster is required.")]
        public string Poster { get; set; }


    }
}
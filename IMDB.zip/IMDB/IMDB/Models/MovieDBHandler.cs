﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace IMDB.Models
{
    public class MovieDBHandler
    {
        private SqlConnection con;
        private void connection()
        {
            string constring = ConfigurationManager.ConnectionStrings["movieconn"].ToString();
            con = new SqlConnection(constring);
        }

        // **************** ADD NEW STUDENT *********************
        public bool AddMovie(Movies smodel)
        {
            connection();
            SqlCommand cmd = new SqlCommand("AddNewMovie", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Name", smodel.Name);
            cmd.Parameters.AddWithValue("@Year_Of_Release", smodel.Year_Of_Release);
            cmd.Parameters.AddWithValue("@Plot", smodel.Plot);
            cmd.Parameters.AddWithValue("@Poster", smodel.Poster);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }

        // ********** VIEW STUDENT DETAILS ********************
        public List<Movies> GetMovie()
        {
            connection();
            List<Movies> movieist = new List<Movies>();

            SqlCommand cmd = new SqlCommand("GetMovieDetails", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            con.Open();
            sd.Fill(dt);
            con.Close();

            foreach (DataRow dr in dt.Rows)
            {
                movieist.Add(
                    new Movies
                    {
                       // n = Convert.ToInt32(dr["Id"]),
                        Name = Convert.ToString(dr["Name"]),
                        Year_Of_Release = Convert.ToString(dr["Year_Of_Release"]),
                        Plot = Convert.ToString(dr["Plot"]),
                        Poster = Convert.ToString(dr["Poster"]),
                    });
            }
            return movieist;
        }

        // ***************** UPDATE STUDENT DETAILS *********************
        //public bool UpdateDetails(Movies smodel)
        //{
        //    connection();
        //    SqlCommand cmd = new SqlCommand("UpdateStudentDetails", con);
        //    cmd.CommandType = CommandType.StoredProcedure;

        //    cmd.Parameters.AddWithValue("@StdId", smodel.Id);
        //    cmd.Parameters.AddWithValue("@Name", smodel.Name);
        //    cmd.Parameters.AddWithValue("@City", smodel.City);
        //    cmd.Parameters.AddWithValue("@Address", smodel.Address);

        //    con.Open();
        //    int i = cmd.ExecuteNonQuery();
        //    con.Close();

        //    if (i >= 1)
        //        return true;
        //    else
        //        return false;
        //}

    }
}
